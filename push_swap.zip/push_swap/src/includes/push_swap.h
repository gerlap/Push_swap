/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: georgiilapshin <georgiilapshin@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/24 19:00:54 by glapshin          #+#    #+#             */
/*   Updated: 2025/04/02 04:55:05 by georgiilaps      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include <stdbool.h>
# include <limits.h>
# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>
# include <stddef.h>

typedef struct s_node
{
	int				value;
	int				index;
	struct s_node	*next;
}	t_node;

t_node	*create_node(int value, int index);
t_node	*argv_to_linked_list(char **argv);
t_node	*get_tail(t_node *head);
void	free_list(t_node *head);
void	print_list(t_node *head);

/* validation */
bool	is_valid_integer(const char *str);
bool	validate_args(char **argv, int argc);
char	*ft_strchr( const char *s, int c);
char	*ft_strtok(char *argv, const char *del);
void	error_exit(void);
bool	dup_check(t_node *stack);
void	append_node(t_node **head, t_node **tail, t_node *new_node);
long	ft_atoi(const char *str);
bool	is_sorted(t_node *stack);

//operators
void	sa(t_node **a);
void	sb(t_node **b);
void	ss(t_node **a, t_node **b);
void	pa(t_node **a, t_node **b);
void	pb(t_node **a, t_node **b);
void	ra(t_node **a);
void	rb(t_node **b);
void	rr(t_node **a, t_node **b);
void	rra(t_node **a);
void	rrb(t_node **b);
void	rrr(t_node **a, t_node **b);

//add_sort
int		stack_size(t_node *stack);
t_node	*get_min(t_node *stack);
int		get_pos(t_node *stack, t_node *target);
void	sort_small(t_node **a, t_node **b);
void	sort_2(t_node **a);
void	sort_3(t_node **a);
void	sort_4_5(t_node **a, t_node **b);
void	turk_sort(t_node **a, t_node **b, int c);
void	assign_indices(t_node *stack);

//additional for tester
void	push_back(t_node **stack, int value);
void	free_stack(t_node *stack);
void	reset_op_count(void);
int		get_op_count(void);

#endif