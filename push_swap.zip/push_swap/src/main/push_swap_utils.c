/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap_utils.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: georgiilapshin <georgiilapshin@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/24 19:17:24 by glapshin          #+#    #+#             */
/*   Updated: 2025/04/02 04:32:13 by georgiilaps      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

// Print the linked list
void	print_list(t_node *head)
{
	t_node	*current;

	current = head;
	while (current)
	{
		printf("%d ", current->value);
		current = current->next;
	}
}

// Function to free the linked list
void	free_list(t_node *head)
{
	t_node	*temp;

	while (head)
	{
		temp = head;
		head = head->next;
		free(temp);
	}
}

t_node	*get_tail(t_node *head)
{
	if (!head)
		return (NULL);
	while (head->next)
		head = head->next;
	return (head);
}

void	error_exit(void)
{
	write(2, "Error\n", 6);
	exit(1);
}

t_node	*create_node(int value, int index)
{
	t_node	*new_node;

	new_node = malloc(sizeof(t_node));
	if (!new_node)
		error_exit();
	new_node->value = value;
	new_node->index = index;
	new_node->next = NULL;
	return (new_node);
}
