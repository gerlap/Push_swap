/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: georgiilapshin <georgiilapshin@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/24 19:00:37 by glapshin          #+#    #+#             */
/*   Updated: 2025/04/02 04:56:36 by georgiilaps      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

t_node	*argv_to_linked_list(char **argv)
{
	int		value;
	int		i;
	t_node	*head;
	t_node	*tail;
	t_node	*new_node;

	i = 1;
	head = NULL;
	tail = NULL;
	while (argv[i])
	{
		value = atoi(argv[i]);
		new_node = create_node(value, i - 1);
		if (!new_node)
			error_exit();
		append_node(&head, &tail, new_node);
		i++;
	}
	return (head);
}

void	append_node(t_node **head, t_node **tail, t_node *new_node)
{
	if (!*head)
	{
		*head = new_node;
		*tail = new_node;
	}
	else
	{
		(*tail)->next = new_node;
		*tail = new_node;
	}
}

int	main(int argc, char **argv)
{
	t_node	*stack_a;
	t_node	*stack_b;

	if (argc == 1)
		return (0);
	if (!validate_args(argv, argc))
		error_exit();
	stack_a = argv_to_linked_list(argv);
	if (!stack_a || dup_check(stack_a))
		error_exit();
	if (is_sorted(stack_a))
		return (0);
	stack_b = NULL;
	if (argc < 7)
	{
		sort_small(&stack_a, &stack_b);
	}
	else
	{
		turk_sort(&stack_a, &stack_b, 16);
	}
	free_list(stack_a);
	return (0);
}
