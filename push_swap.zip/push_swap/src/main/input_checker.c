/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   input_checker.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: georgiilapshin <georgiilapshin@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/28 04:58:00 by glapshin          #+#    #+#             */
/*   Updated: 2025/04/02 04:53:32 by georgiilaps      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

bool	is_valid_integer(const char *str)
{
	long		numb;
	const char	*orig_str;
	
	orig_str = str;
	if (!str || !*str)
		return (false);
	if (*str == '-' || *str == '+')
		str++;
	while (*str)
	{
		if (*str < '0' || *str > '9')
			return (false);
		str++;
	}
	numb = ft_atoi(orig_str);
	if (numb > 2147483647 || numb < -2147483648)
		error_exit();
	return (true);
}

bool	validate_args(char **argv, int argc)
{
	int	i;

	i = 1;
	while (i < argc)
	{
		if (!is_valid_integer(argv[i]))
		{
			printf("huj sosi3");
			error_exit();
		}
		i++;
	}
	return (true);
}

bool	dup_check(t_node *stack)
{
	t_node	*cur;
	t_node	*runner;

	cur = stack;
	while (cur)
	{
		runner = cur->next;
		while (runner)
		{
			if (runner->value == cur->value)
				return (true);
			runner = runner->next;
		}
		cur = cur->next;
	}
	return (false);
}

bool	is_sorted(t_node *stack)
{
	while (stack && stack->next)
	{
		if (stack->value > stack->next->value)
			return false;
		stack = stack->next;
	}
	return true;
}
