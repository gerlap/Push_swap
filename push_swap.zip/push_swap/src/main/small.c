/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   small.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glapshin <glapshin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/24 22:44:46 by glapshin          #+#    #+#             */
/*   Updated: 2025/04/01 21:51:31 by glapshin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	sort_small(t_node **a, t_node **b)
{
	int	size;

	size = stack_size(*a);
	if (size == 2)
		sort_2(a);
	else if (size == 3)
		sort_3(a);
	else if (size == 4 || size == 5)
		sort_4_5(a, b);
}

void	sort_2(t_node **a)
{
	if ((*a)->value > (*a)->next->value)
		sa(a);
}

void	sort_3(t_node **a)
{
	int	x;
	int	y;
	int	z;

	x = (*a)->value;
	y = (*a)->next->value;
	z = (*a)->next->next->value;
	if (x > y && y < z && x < z)
		sa(a);
	else if (x > y && y > z)
	{
		sa(a);
		rra(a);
	}
	else if (x > y && y < z && x > z)
		ra(a);
	else if (x < y && y > z && x < z)
	{
		sa(a);
		ra(a);
	}
	else if (x < y && y > z && x > z)
		rra(a);
}

void	sort_4_5(t_node **a, t_node **b)
{
	t_node	*min;
	int		pos;

	while (stack_size(*a) > 3)
	{
		min = get_min(*a);
		pos = get_pos(*a, min);
		if (pos <= stack_size(*a) / 2)
			while (*a != min)
				ra(a);
		else
			while (*a != min)
				rra(a);
		pb(a, b);
	}
	sort_3(a);
	while (*b)
		pa(a, b);
}
