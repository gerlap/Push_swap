/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   input_tokenizer.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: georgiilapshin <georgiilapshin@student.    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/29 20:08:54 by glapshin          #+#    #+#             */
/*   Updated: 2025/04/02 04:43:10 by georgiilaps      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

char	*ft_strchr(const char *s, int c)
{
	while (*s)
	{
		if (*s == (char)c)
		{
			return ((char *)s);
		}
		s++;
	}
	if (c == '\0')
	{
		return ((char *)s);
	}
	return (NULL);
}

char	*ft_strtok(char *argv, const char *del)
{
	static char *check_point;
	char *token;

	if (argv)
		check_point = argv;
	if (!check_point || *check_point == '\0')
		error_exit();
	while (*check_point && ft_strchr(del, *check_point))
		check_point++;
	if (!*check_point)
		error_exit();
	token = check_point;
	while (*check_point && !ft_strchr(del, *check_point))
		check_point++;
	if (*check_point)
	{
		*check_point = '\0';
		check_point++;
	}
	return (token);
}

long	ft_atoi(const char *str)
{
	long	i;
	long	sign;
	long	result;

	i = 0;
	sign = 1;
	result = 0;
	while (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))
		i++;
	if (str[i] == '-' || str[i] == '+')
	{
		if (str[i] == '-')
			sign = -1;
		i++;
	}
	while (str[i] >= '0' && str[i] <= '9')
	{
		result = result * 10 + (str[i] - '0');
		i++;
	}
	return (result * sign);
}