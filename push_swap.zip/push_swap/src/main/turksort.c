/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   turksort.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glapshin <glapshin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/28 00:04:23 by glapshin          #+#    #+#             */
/*   Updated: 2025/04/01 20:42:29 by glapshin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

static t_node	*get_max(t_node *stack)
{
	t_node	*max;

	max = stack;
	while (stack)
	{
		if (stack->index > max->index)
			max = stack;
		stack = stack->next;
	}
	return (max);
}

void	assign_indices(t_node *stack)
{
	int		size;
	int		*arr;
	t_node	*cur;
	int		tmp;

	size = stack_size(stack);
	arr = malloc(sizeof(int) * size);
	cur = stack;
	for (int i = 0; cur; i++, cur = cur->next)
		arr[i] = cur->value;
	for (int i = 0; i < size - 1; i++)
		for (int j = i + 1; j < size; j++)
			if (arr[i] > arr[j])
			{
				tmp = arr[i];
				arr[i] = arr[j];
				arr[j] = tmp;
			}
	for (cur = stack; cur; cur = cur->next)
		for (int i = 0; i < size; i++)
			if (cur->value == arr[i])
			{
				cur->index = i;
				break ;
			}
	free(arr);
}

void	turk_sort(t_node **a, t_node **b, int c)
{
	int		size;
	int		i;
	int		range;
	t_node	*max;
	int		pos;
	int		len;

	assign_indices(*a);
	size = stack_size(*a);
	i = 0;
	range = size / c + (size % c != 0);
	while (*a)
	{
		if ((*a)->index <= i)
		{
			pb(a, b);
			rb(b);
			i++;
		}
		else if ((*a)->index <= i + range)
		{
			pb(a, b);
			i++;
		}
		else
			ra(a);
	}
	while (*b)
	{
		max = get_max(*b);
		pos = get_pos(*b, max);
		len = stack_size(*b);
		if (pos <= len / 2)
			while (*b != max)
				rb(b);
		else
			while (*b != max)
				rrb(b);
		pa(a, b);
	}
}
