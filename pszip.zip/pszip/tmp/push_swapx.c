/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glapshin <glapshin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/24 19:00:37 by glapshin          #+#    #+#             */
/*   Updated: 2025/03/28 04:05:40 by glapshin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

t_node *stack_a = NULL;
t_node *stack_b = NULL;
t_node *stack_c = NULL;

static size_t	ft_countword(char const *s, char c)
{
	size_t	count;

	if (!*s)
		return (0);
	count = 0;
	while (*s)
	{
		while (*s == c)
			s++;
		if (*s)
			count++;
		while (*s != c && *s)
			s++;
	}
	return (count);
}

char	**ft_split(char const *s, char c)
{
	char	**lst;
	size_t	word_len;
	int		i;

	lst = (char **)malloc((ft_countword(s, c) + 1) * sizeof(char *));
	if (!s || !lst)
		return (0);
	i = 0;
	while (*s)
	{
		while (*s == c && *s)
			s++;
		if (*s)
		{
			if (!ft_strchr(s, c))
				word_len = ft_strlen(s);
			else
				word_len = ft_strchr(s, c) - s;
			lst[i++] = ft_substr(s, 0, word_len);
			s += word_len;
		}
	}
	lst[i] = NULL;
	return (lst);
}

int	ft_atoi(const char *str)
{
	int	i;
	int	number;
	int	sign;

	i = 0;
	number = 0;
	sign = 1;
	if (!str)
		return (0);
	while (str[i] == 32 || (str[i] >= 9 && str[i] <= 13))
		i++;
	if (str[i] == '-')
	{
		sign = -sign;
		i++;
	}
	else if (str[i] == '+')
		i++;
	while (str[i] >= '0' && str[i] <= '9')
	{
		number = number * 10 + str[i] - '0';
		i++;
	}
	return (number * sign);
}

t_node *create_node(int value, int index) {
    t_node *new_node = malloc(sizeof(t_node));
    if (!new_node)
        return NULL;
    new_node->value = value;
    new_node->index = index;
    new_node->next = NULL;
    new_node->prev = NULL;
    return new_node;
}

// Function to convert argv to a doubly linked list
t_node *argv_to_linked_list(int argc, char **argv) {
    if (argc < 2) {
        printf("Error: No arguments provided.\n");
        return NULL;
    }

    t_node *head = NULL, *tail = NULL;
    for (int i = 1; i < argc; i++) {
        int value = atoi(argv[i]);
        t_node *new_node = create_node(value, i - 1);
        if (!new_node) {
            printf("Error: Memory allocation failed.\n");
            return NULL;
        }

        if (!head) {
            head = new_node;
            tail = new_node;
        } else {
            tail->next = new_node;
            new_node->prev = tail;
            tail = new_node;
        }
    }
    return head;
}

int main(int argc, char **argv) {
    char    **split_arg;


    if (argc == 1) {
        printf("Usage: %s <list of integers>\n", argv[0]);
        return 1;
    }

    if (!validate_args(argv, argc))
	    error_exit();
    
    if (argc == 2)
        split_arg = ft_split(argv[1], " ");
    int i = 0;
    stack_c = argv_to_linked_list(2, split_arg);
    stack_a = argv_to_linked_list(argc, argv);
    stack_b = NULL;

    if (!stack_a)
	    error_exit();

    if(argc < 7)
    {
        sort_small(&stack_a, &stack_b);
    }
    else 
    {
        turk_sort(&stack_a, &stack_b, 16);
    }
    free_list(stack_a);

    return 0;
}

