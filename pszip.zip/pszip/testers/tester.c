/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   tester.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glapshin <glapshin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/26 00:21:22 by georgiilaps       #+#    #+#             */
/*   Updated: 2025/03/28 04:54:30 by glapshin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "push_swap.h"

#define SIZE opt
#define RUNS 100

t_node *generate_random_stack(int size) {
    int *arr = malloc(size * sizeof(int));
    for (int i = 0; i < size; i++) arr[i] = i;
    for (int i = size - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int tmp = arr[i]; arr[i] = arr[j]; arr[j] = tmp;
    }
    t_node *stack = NULL;
    for (int i = 0; i < size; i++) push_back(&stack, arr[i]);
    free(arr);
    return stack;
}

t_node *tester_create_node(int value) {
    t_node *new_node = malloc(sizeof(t_node));
    if (!new_node)
        return NULL;
    new_node->value = value;
    new_node->index = -1;
    new_node->next = NULL;
    new_node->prev = NULL;
    return new_node;
}

void push_back(t_node **stack, int value) {
    t_node *new = tester_create_node(value);
    if (!new)
        return;

    if (!*stack) {
        *stack = new;
        return;
    }

    t_node *cur = *stack;
    while (cur->next)
        cur = cur->next;
    cur->next = new;
    new->prev = cur;
}

int main(int argc, char **argv) {
    int opt;
    int fail_size;
    if(argc == 2)
        opt = atoi(argv[1]);
    if(opt == 100)
    {
        fail_size = 699;
    }
    else
    {
        fail_size = 5499;
    }
    srand(time(NULL));
    int op_count = 0;
    int total_ops = 0;
    int fail = 0;
        op_count = 0;
        for (int run = 0; run < RUNS; run++) {
            t_node *a = generate_random_stack(SIZE);
            t_node *b = NULL;

            turk_sort(&a, &b, 16);

            op_count = get_op_count();
            printf("%d, ", op_count);
            if(op_count > fail_size)
                fail++;
            reset_op_count();
            free_list(a);
            free_list(b);
            total_ops +=op_count;
        }
        printf("\n");
        double avg = (double)total_ops / RUNS;
        total_ops = 0;
        printf("%.2f\n", avg);
        double fail_ratio = (double)fail / RUNS * 100;
        printf("fails: %.2f%%\n", fail_ratio);
    return 0;
}
