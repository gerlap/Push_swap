/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   input_checker.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glapshin <glapshin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/28 04:58:00 by glapshin          #+#    #+#             */
/*   Updated: 2025/03/28 06:27:55 by glapshin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

bool	check_limits(long numb)
{
	if (numb > 2147483647 || numb < -2147483648)
		return (false);
	return (true);
}

bool is_valid_integer(char *str) 
{   
    int numb = atoi(str);
    if (!check_limits(numb))
        error_exit();
    if (*str == '-' || *str == '+') str++;
    while (*str) {
        if (*str < '0' || *str > '9')
            return false;
        str++;
    }
    return true;
}

bool validate_args(char **argv, int argc) {
    for (int i = 1; i < argc; i++) {
        if (!is_valid_integer(argv[i])) {
            error_exit();
            return false;
        }
    }
    return true;
}