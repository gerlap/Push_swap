/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.utils.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glapshin <glapshin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/24 19:17:24 by glapshin          #+#    #+#             */
/*   Updated: 2025/03/28 05:36:02 by glapshin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "push_swap.h"

// Print the linked list
void print_list(t_node *head) {
    t_node *current = head;
    while (current) {
        printf("%d ", current->value);
        current = current->next;
    }
}

// Function to free the linked list
void free_list(t_node *head) {
    while (head) {
        t_node *temp = head;
        head = head->next;
        free(temp);
    }
}
// Return the tail (last node) of the doubly linked list
t_node *get_tail(t_node *head) {
    if (!head)
        return NULL;
    while (head->next)
        head = head->next;
    return head;
}

void	error_exit(void)
{
	write(2, "Error\n", 6);
	exit(1);
}
