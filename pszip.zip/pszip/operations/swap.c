/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   swap.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glapshin <glapshin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/28 06:42:33 by glapshin          #+#    #+#             */
/*   Updated: 2025/03/28 06:42:58 by glapshin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

static void swap(t_node **stack) {
    if (*stack && (*stack)->next) {
        t_node *first = *stack;
        t_node *second = first->next;

        first->next = second->next;
        if (second->next)
            second->next->prev = first;

        second->prev = NULL;
        second->next = first;
        first->prev = second;

        *stack = second;
    }
}

void sa(t_node **a) 
{ 
    swap(a); write(1, "sa\n", 3); 
}
void sb(t_node **b) 
{
    swap(b); write(1, "sb\n", 3);
}
void ss(t_node **a, t_node **b) 
{
    swap(a); swap(b); write(1, "ss\n", 3);
}