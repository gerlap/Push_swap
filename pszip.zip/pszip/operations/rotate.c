/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rotate.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glapshin <glapshin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/28 06:46:00 by glapshin          #+#    #+#             */
/*   Updated: 2025/03/28 06:46:16 by glapshin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

static void rotate(t_node **stack) {
    if (*stack && (*stack)->next) {
        t_node *first = *stack;
        t_node *last = *stack;

        *stack = first->next;
        (*stack)->prev = NULL;

        while (last->next)
            last = last->next;

        last->next = first;
        first->prev = last;
        first->next = NULL;
    }
}

void ra(t_node **a) 
{
    rotate(a); write(1, "ra\n", 3);   
}
void rb(t_node **b) 
{
    rotate(b); write(1, "rb\n", 3);
}
void rr(t_node **a, t_node **b) 
{
    rotate(a); rotate(b); write(1, "rr\n", 3);
}