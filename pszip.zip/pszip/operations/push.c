/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: glapshin <glapshin@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/28 06:44:45 by glapshin          #+#    #+#             */
/*   Updated: 2025/03/28 06:45:03 by glapshin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../push_swap.h"

static void push(t_node **src, t_node **dest) {
    if (*src) {
        t_node *node = *src;
        *src = node->next;
        if (*src)
            (*src)->prev = NULL;

        node->next = *dest;
        if (*dest)
            (*dest)->prev = node;

        node->prev = NULL; 
        *dest = node;
    }
}

void pa(t_node **a, t_node **b) 
{ 
    push(b, a); write(1, "pa\n", 3);
}
void pb(t_node **a, t_node **b) 
{
    push(a, b); write(1, "pb\n", 3);
}
